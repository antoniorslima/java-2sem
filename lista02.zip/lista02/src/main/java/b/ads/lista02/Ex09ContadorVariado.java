/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package b.ads.lista02;


/**
 *
 * @author aluno
 */
public class Ex09ContadorVariado {
    public static void main(String[] args) {
        for (Double i = 0.15; i < 5.00; i+= 0.15) {
            System.out.println(String.format("%.2f", i));
            
        }
    }
}
